package com.mphasis.laboratory.controller;

public class TechnicianController {

}
