package com.mphasis.laboratory.service;

public class AppointmentService {

}
