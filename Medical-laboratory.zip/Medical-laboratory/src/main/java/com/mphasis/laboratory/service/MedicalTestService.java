package com.mphasis.laboratory.service;

public class MedicalTestService {

}
