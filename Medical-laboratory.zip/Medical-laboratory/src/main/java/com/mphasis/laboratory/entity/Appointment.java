package com.mphasis.laboratory.entity;

public class Appointment {

}
