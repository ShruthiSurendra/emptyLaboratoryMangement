package com.mphasis.laboratory.controller;

public class AppointmentController {

}
